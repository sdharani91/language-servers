"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ToolInputSchemaFilterSensitiveLog = exports.ToolResultFilterSensitiveLog = exports.ToolResultStatus = exports.ToolResultContentBlockFilterSensitiveLog = exports.ToolResultContentBlock = exports.ShellStateFilterSensitiveLog = exports.ShellHistoryEntryFilterSensitiveLog = exports.GitStateFilterSensitiveLog = exports.EnvStateFilterSensitiveLog = exports.EnvironmentVariableFilterSensitiveLog = exports.EditorStateFilterSensitiveLog = exports.RelevantTextDocumentFilterSensitiveLog = exports.ContentType = exports.CursorState = exports.DiagnosticFilterSensitiveLog = exports.Diagnostic = exports.TextDocumentDiagnosticFilterSensitiveLog = exports.DiagnosticTag = exports.DiagnosticRelatedInformationFilterSensitiveLog = exports.DiagnosticLocationFilterSensitiveLog = exports.TextDocumentFilterSensitiveLog = exports.SymbolType = exports.CodeDescriptionFilterSensitiveLog = exports.RuntimeDiagnosticFilterSensitiveLog = exports.DiagnosticSeverity = exports.ConsoleStateFilterSensitiveLog = exports.Origin = exports.ImageBlockFilterSensitiveLog = exports.ImageSourceFilterSensitiveLog = exports.ImageSource = exports.ImageFormat = exports.ConflictException = exports.ConflictExceptionReason = exports.AssistantResponseMessageFilterSensitiveLog = exports.ToolUseFilterSensitiveLog = exports.SupplementaryWebLinkFilterSensitiveLog = exports.FollowupPromptFilterSensitiveLog = exports.UserIntent = exports.AssistantResponseEventFilterSensitiveLog = exports.AppStudioStateFilterSensitiveLog = exports.ValidationException = exports.ValidationExceptionReason = exports.ThrottlingException = exports.ThrottlingExceptionReason = exports.ResourceNotFoundException = exports.InternalServerException = exports.InternalServerExceptionReason = exports.AdditionalContentEntryFilterSensitiveLog = exports.AccessDeniedException = exports.AccessDeniedExceptionReason = void 0;
exports.ChatResponseStream = exports.ToolUseEventFilterSensitiveLog = exports.ToolResultEventFilterSensitiveLog = exports.SupplementaryWebLinksEventFilterSensitiveLog = exports.InvalidStateReason = exports.InteractionComponentsEventFilterSensitiveLog = exports.InteractionComponentEntryFilterSensitiveLog = exports.InteractionComponentFilterSensitiveLog = exports.TaskDetailsFilterSensitiveLog = exports.TaskOverviewFilterSensitiveLog = exports.TaskComponentFilterSensitiveLog = exports.TaskActionFilterSensitiveLog = exports.TaskActionNoteFilterSensitiveLog = exports.TaskActionNoteType = exports.TaskActionConfirmationFilterSensitiveLog = exports.SuggestionsFilterSensitiveLog = exports.SuggestionFilterSensitiveLog = exports.SectionFilterSensitiveLog = exports.SectionComponentFilterSensitiveLog = exports.ResourceListFilterSensitiveLog = exports.ResourceFilterSensitiveLog = exports.ProgressFilterSensitiveLog = exports.ProgressComponentFilterSensitiveLog = exports.StepFilterSensitiveLog = exports.StepState = exports.StepComponentFilterSensitiveLog = exports.InfrastructureUpdateFilterSensitiveLog = exports.InfrastructureUpdateTransitionFilterSensitiveLog = exports.AlertFilterSensitiveLog = exports.AlertType = exports.AlertComponentFilterSensitiveLog = exports.TextFilterSensitiveLog = exports.ActionFilterSensitiveLog = exports.WebLinkFilterSensitiveLog = exports.ModuleLinkFilterSensitiveLog = exports.CloudWatchTroubleshootingLinkFilterSensitiveLog = exports.IntentsEventFilterSensitiveLog = exports.IntentDataType = exports.IntentType = exports.FollowupPromptEventFilterSensitiveLog = exports.CodeEventFilterSensitiveLog = exports.CitationEventFilterSensitiveLog = exports.CitationTarget = exports.ChatMessageFilterSensitiveLog = exports.ChatMessage = exports.UserInputMessageFilterSensitiveLog = exports.UserInputMessageContextFilterSensitiveLog = exports.ToolFilterSensitiveLog = exports.Tool = exports.ToolSpecificationFilterSensitiveLog = void 0;
exports.GenerateCodeFromCommandsResponseFilterSensitiveLog = exports.GenerateCodeFromCommandsResponseStreamFilterSensitiveLog = exports.GenerateCodeFromCommandsResponseStream = exports.GenerateCodeFromCommandsRequestFilterSensitiveLog = exports.SendMessageResponseFilterSensitiveLog = exports.SendMessageRequestFilterSensitiveLog = exports.ServiceQuotaExceededException = exports.ServiceQuotaExceededExceptionReason = exports.OutputFormat = exports.DryRunOperationException = exports.ConversationStateFilterSensitiveLog = exports.CommandInputFilterSensitiveLog = exports.CommandInput = exports.ChatTriggerType = exports.ChatResponseStreamFilterSensitiveLog = void 0;
const QDeveloperStreamingServiceException_1 = require("./QDeveloperStreamingServiceException");
const smithy_client_1 = require("@smithy/smithy-client");
exports.AccessDeniedExceptionReason = {
    UNAUTHORIZED_CUSTOMIZATION_RESOURCE_ACCESS: "UNAUTHORIZED_CUSTOMIZATION_RESOURCE_ACCESS",
    UNAUTHORIZED_WORKSPACE_CONTEXT_FEATURE_ACCESS: "UNAUTHORIZED_WORKSPACE_CONTEXT_FEATURE_ACCESS",
};
class AccessDeniedException extends QDeveloperStreamingServiceException_1.QDeveloperStreamingServiceException {
    name = "AccessDeniedException";
    $fault = "client";
    reason;
    constructor(opts) {
        super({
            name: "AccessDeniedException",
            $fault: "client",
            ...opts
        });
        Object.setPrototypeOf(this, AccessDeniedException.prototype);
        this.reason = opts.reason;
    }
}
exports.AccessDeniedException = AccessDeniedException;
const AdditionalContentEntryFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.name && { name: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.description && { description: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.innerContext && { innerContext: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.AdditionalContentEntryFilterSensitiveLog = AdditionalContentEntryFilterSensitiveLog;
exports.InternalServerExceptionReason = {
    MODEL_TEMPORARILY_UNAVAILABLE: "MODEL_TEMPORARILY_UNAVAILABLE",
};
class InternalServerException extends QDeveloperStreamingServiceException_1.QDeveloperStreamingServiceException {
    name = "InternalServerException";
    $fault = "server";
    $retryable = {};
    reason;
    constructor(opts) {
        super({
            name: "InternalServerException",
            $fault: "server",
            ...opts
        });
        Object.setPrototypeOf(this, InternalServerException.prototype);
        this.reason = opts.reason;
    }
}
exports.InternalServerException = InternalServerException;
class ResourceNotFoundException extends QDeveloperStreamingServiceException_1.QDeveloperStreamingServiceException {
    name = "ResourceNotFoundException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ResourceNotFoundException",
            $fault: "client",
            ...opts
        });
        Object.setPrototypeOf(this, ResourceNotFoundException.prototype);
    }
}
exports.ResourceNotFoundException = ResourceNotFoundException;
exports.ThrottlingExceptionReason = {
    MONTHLY_REQUEST_COUNT: "MONTHLY_REQUEST_COUNT",
};
class ThrottlingException extends QDeveloperStreamingServiceException_1.QDeveloperStreamingServiceException {
    name = "ThrottlingException";
    $fault = "client";
    $retryable = {
        throttling: true,
    };
    reason;
    constructor(opts) {
        super({
            name: "ThrottlingException",
            $fault: "client",
            ...opts
        });
        Object.setPrototypeOf(this, ThrottlingException.prototype);
        this.reason = opts.reason;
    }
}
exports.ThrottlingException = ThrottlingException;
exports.ValidationExceptionReason = {
    CONTENT_LENGTH_EXCEEDS_THRESHOLD: "CONTENT_LENGTH_EXCEEDS_THRESHOLD",
    INVALID_CONVERSATION_ID: "INVALID_CONVERSATION_ID",
    INVALID_KMS_GRANT: "INVALID_KMS_GRANT",
};
class ValidationException extends QDeveloperStreamingServiceException_1.QDeveloperStreamingServiceException {
    name = "ValidationException";
    $fault = "client";
    reason;
    constructor(opts) {
        super({
            name: "ValidationException",
            $fault: "client",
            ...opts
        });
        Object.setPrototypeOf(this, ValidationException.prototype);
        this.reason = opts.reason;
    }
}
exports.ValidationException = ValidationException;
const AppStudioStateFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.namespace && { namespace: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.propertyName && { propertyName: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.propertyValue && { propertyValue: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.propertyContext && { propertyContext: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.AppStudioStateFilterSensitiveLog = AppStudioStateFilterSensitiveLog;
const AssistantResponseEventFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.content && { content: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.AssistantResponseEventFilterSensitiveLog = AssistantResponseEventFilterSensitiveLog;
exports.UserIntent = {
    APPLY_COMMON_BEST_PRACTICES: "APPLY_COMMON_BEST_PRACTICES",
    CITE_SOURCES: "CITE_SOURCES",
    CODE_GENERATION: "CODE_GENERATION",
    EXPLAIN_CODE_SELECTION: "EXPLAIN_CODE_SELECTION",
    EXPLAIN_LINE_BY_LINE: "EXPLAIN_LINE_BY_LINE",
    GENERATE_CLOUDFORMATION_TEMPLATE: "GENERATE_CLOUDFORMATION_TEMPLATE",
    GENERATE_UNIT_TESTS: "GENERATE_UNIT_TESTS",
    IMPROVE_CODE: "IMPROVE_CODE",
    SHOW_EXAMPLES: "SHOW_EXAMPLES",
    SUGGEST_ALTERNATE_IMPLEMENTATION: "SUGGEST_ALTERNATE_IMPLEMENTATION",
};
const FollowupPromptFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.content && { content: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.FollowupPromptFilterSensitiveLog = FollowupPromptFilterSensitiveLog;
const SupplementaryWebLinkFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.url && { url: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.title && { title: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.snippet && { snippet: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.SupplementaryWebLinkFilterSensitiveLog = SupplementaryWebLinkFilterSensitiveLog;
const ToolUseFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.name && { name: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.input && { input: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.ToolUseFilterSensitiveLog = ToolUseFilterSensitiveLog;
const AssistantResponseMessageFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.content && { content: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.supplementaryWebLinks && { supplementaryWebLinks: obj.supplementaryWebLinks.map(item => (0, exports.SupplementaryWebLinkFilterSensitiveLog)(item))
    }),
    ...(obj.followupPrompt && { followupPrompt: (0, exports.FollowupPromptFilterSensitiveLog)(obj.followupPrompt)
    }),
    ...(obj.toolUses && { toolUses: obj.toolUses.map(item => (0, exports.ToolUseFilterSensitiveLog)(item))
    }),
});
exports.AssistantResponseMessageFilterSensitiveLog = AssistantResponseMessageFilterSensitiveLog;
exports.ConflictExceptionReason = {
    CUSTOMER_KMS_KEY_DISABLED: "CUSTOMER_KMS_KEY_DISABLED",
    CUSTOMER_KMS_KEY_INVALID_KEY_POLICY: "CUSTOMER_KMS_KEY_INVALID_KEY_POLICY",
    MISMATCHED_KMS_KEY: "MISMATCHED_KMS_KEY",
};
class ConflictException extends QDeveloperStreamingServiceException_1.QDeveloperStreamingServiceException {
    name = "ConflictException";
    $fault = "client";
    reason;
    constructor(opts) {
        super({
            name: "ConflictException",
            $fault: "client",
            ...opts
        });
        Object.setPrototypeOf(this, ConflictException.prototype);
        this.reason = opts.reason;
    }
}
exports.ConflictException = ConflictException;
exports.ImageFormat = {
    GIF: "gif",
    JPEG: "jpeg",
    PNG: "png",
    WEBP: "webp",
};
var ImageSource;
(function (ImageSource) {
    ImageSource.visit = (value, visitor) => {
        if (value.bytes !== undefined)
            return visitor.bytes(value.bytes);
        return visitor._(value.$unknown[0], value.$unknown[1]);
    };
})(ImageSource || (exports.ImageSource = ImageSource = {}));
const ImageSourceFilterSensitiveLog = (obj) => {
    if (obj.bytes !== undefined)
        return { bytes: obj.bytes
        };
    if (obj.$unknown !== undefined)
        return { [obj.$unknown[0]]: 'UNKNOWN' };
};
exports.ImageSourceFilterSensitiveLog = ImageSourceFilterSensitiveLog;
const ImageBlockFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.source && { source: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.ImageBlockFilterSensitiveLog = ImageBlockFilterSensitiveLog;
exports.Origin = {
    AI_EDITOR: "AI_EDITOR",
    CHATBOT: "CHATBOT",
    CLI: "CLI",
    CONSOLE: "CONSOLE",
    DOCUMENTATION: "DOCUMENTATION",
    GITLAB: "GITLAB",
    IDE: "IDE",
    MARKETING: "MARKETING",
    MD: "MD",
    MOBILE: "MOBILE",
    OPENSEARCH_DASHBOARD: "OPENSEARCH_DASHBOARD",
    SAGE_MAKER: "SAGE_MAKER",
    SERVICE_INTERNAL: "SERVICE_INTERNAL",
    UNIFIED_SEARCH: "UNIFIED_SEARCH",
    UNKNOWN: "UNKNOWN",
};
const ConsoleStateFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.consoleUrl && { consoleUrl: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.taskName && { taskName: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.ConsoleStateFilterSensitiveLog = ConsoleStateFilterSensitiveLog;
exports.DiagnosticSeverity = {
    ERROR: "ERROR",
    HINT: "HINT",
    INFORMATION: "INFORMATION",
    WARNING: "WARNING",
};
const RuntimeDiagnosticFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.source && { source: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.message && { message: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.RuntimeDiagnosticFilterSensitiveLog = RuntimeDiagnosticFilterSensitiveLog;
const CodeDescriptionFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.href && { href: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.CodeDescriptionFilterSensitiveLog = CodeDescriptionFilterSensitiveLog;
exports.SymbolType = {
    DECLARATION: "DECLARATION",
    USAGE: "USAGE",
};
const TextDocumentFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.relativeFilePath && { relativeFilePath: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.text && { text: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.TextDocumentFilterSensitiveLog = TextDocumentFilterSensitiveLog;
const DiagnosticLocationFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.uri && { uri: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.DiagnosticLocationFilterSensitiveLog = DiagnosticLocationFilterSensitiveLog;
const DiagnosticRelatedInformationFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.location && { location: (0, exports.DiagnosticLocationFilterSensitiveLog)(obj.location)
    }),
    ...(obj.message && { message: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.DiagnosticRelatedInformationFilterSensitiveLog = DiagnosticRelatedInformationFilterSensitiveLog;
exports.DiagnosticTag = {
    DEPRECATED: "DEPRECATED",
    UNNECESSARY: "UNNECESSARY",
};
const TextDocumentDiagnosticFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.document && { document: (0, exports.TextDocumentFilterSensitiveLog)(obj.document)
    }),
    ...(obj.source && { source: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.message && { message: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.code && { code: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.codeDescription && { codeDescription: (0, exports.CodeDescriptionFilterSensitiveLog)(obj.codeDescription)
    }),
    ...(obj.relatedInformation && { relatedInformation: obj.relatedInformation.map(item => (0, exports.DiagnosticRelatedInformationFilterSensitiveLog)(item))
    }),
    ...(obj.data && { data: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.TextDocumentDiagnosticFilterSensitiveLog = TextDocumentDiagnosticFilterSensitiveLog;
var Diagnostic;
(function (Diagnostic) {
    Diagnostic.visit = (value, visitor) => {
        if (value.textDocumentDiagnostic !== undefined)
            return visitor.textDocumentDiagnostic(value.textDocumentDiagnostic);
        if (value.runtimeDiagnostic !== undefined)
            return visitor.runtimeDiagnostic(value.runtimeDiagnostic);
        return visitor._(value.$unknown[0], value.$unknown[1]);
    };
})(Diagnostic || (exports.Diagnostic = Diagnostic = {}));
const DiagnosticFilterSensitiveLog = (obj) => {
    if (obj.textDocumentDiagnostic !== undefined)
        return { textDocumentDiagnostic: (0, exports.TextDocumentDiagnosticFilterSensitiveLog)(obj.textDocumentDiagnostic)
        };
    if (obj.runtimeDiagnostic !== undefined)
        return { runtimeDiagnostic: (0, exports.RuntimeDiagnosticFilterSensitiveLog)(obj.runtimeDiagnostic)
        };
    if (obj.$unknown !== undefined)
        return { [obj.$unknown[0]]: 'UNKNOWN' };
};
exports.DiagnosticFilterSensitiveLog = DiagnosticFilterSensitiveLog;
var CursorState;
(function (CursorState) {
    CursorState.visit = (value, visitor) => {
        if (value.position !== undefined)
            return visitor.position(value.position);
        if (value.range !== undefined)
            return visitor.range(value.range);
        return visitor._(value.$unknown[0], value.$unknown[1]);
    };
})(CursorState || (exports.CursorState = CursorState = {}));
exports.ContentType = {
    CODE: "CODE",
    FILE: "FILE",
    PROMPT: "PROMPT",
    WORKSPACE: "WORKSPACE",
};
const RelevantTextDocumentFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.relativeFilePath && { relativeFilePath: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.text && { text: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.RelevantTextDocumentFilterSensitiveLog = RelevantTextDocumentFilterSensitiveLog;
const EditorStateFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.document && { document: (0, exports.TextDocumentFilterSensitiveLog)(obj.document)
    }),
    ...(obj.cursorState && { cursorState: obj.cursorState
    }),
    ...(obj.relevantDocuments && { relevantDocuments: obj.relevantDocuments.map(item => (0, exports.RelevantTextDocumentFilterSensitiveLog)(item))
    }),
    ...(obj.workspaceFolders && { workspaceFolders: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.EditorStateFilterSensitiveLog = EditorStateFilterSensitiveLog;
const EnvironmentVariableFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.key && { key: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.value && { value: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.EnvironmentVariableFilterSensitiveLog = EnvironmentVariableFilterSensitiveLog;
const EnvStateFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.currentWorkingDirectory && { currentWorkingDirectory: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.environmentVariables && { environmentVariables: obj.environmentVariables.map(item => (0, exports.EnvironmentVariableFilterSensitiveLog)(item))
    }),
});
exports.EnvStateFilterSensitiveLog = EnvStateFilterSensitiveLog;
const GitStateFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.status && { status: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.GitStateFilterSensitiveLog = GitStateFilterSensitiveLog;
const ShellHistoryEntryFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.command && { command: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.directory && { directory: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.stdout && { stdout: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.stderr && { stderr: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.ShellHistoryEntryFilterSensitiveLog = ShellHistoryEntryFilterSensitiveLog;
const ShellStateFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.shellHistory && { shellHistory: obj.shellHistory.map(item => (0, exports.ShellHistoryEntryFilterSensitiveLog)(item))
    }),
});
exports.ShellStateFilterSensitiveLog = ShellStateFilterSensitiveLog;
var ToolResultContentBlock;
(function (ToolResultContentBlock) {
    ToolResultContentBlock.visit = (value, visitor) => {
        if (value.text !== undefined)
            return visitor.text(value.text);
        if (value.json !== undefined)
            return visitor.json(value.json);
        return visitor._(value.$unknown[0], value.$unknown[1]);
    };
})(ToolResultContentBlock || (exports.ToolResultContentBlock = ToolResultContentBlock = {}));
const ToolResultContentBlockFilterSensitiveLog = (obj) => {
    if (obj.text !== undefined)
        return { text: smithy_client_1.SENSITIVE_STRING
        };
    if (obj.json !== undefined)
        return { json: smithy_client_1.SENSITIVE_STRING
        };
    if (obj.$unknown !== undefined)
        return { [obj.$unknown[0]]: 'UNKNOWN' };
};
exports.ToolResultContentBlockFilterSensitiveLog = ToolResultContentBlockFilterSensitiveLog;
exports.ToolResultStatus = {
    ERROR: "error",
    SUCCESS: "success",
};
const ToolResultFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.content && { content: obj.content.map(item => (0, exports.ToolResultContentBlockFilterSensitiveLog)(item))
    }),
});
exports.ToolResultFilterSensitiveLog = ToolResultFilterSensitiveLog;
const ToolInputSchemaFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.json && { json: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.ToolInputSchemaFilterSensitiveLog = ToolInputSchemaFilterSensitiveLog;
const ToolSpecificationFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.inputSchema && { inputSchema: (0, exports.ToolInputSchemaFilterSensitiveLog)(obj.inputSchema)
    }),
    ...(obj.name && { name: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.description && { description: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.ToolSpecificationFilterSensitiveLog = ToolSpecificationFilterSensitiveLog;
var Tool;
(function (Tool) {
    Tool.visit = (value, visitor) => {
        if (value.toolSpecification !== undefined)
            return visitor.toolSpecification(value.toolSpecification);
        return visitor._(value.$unknown[0], value.$unknown[1]);
    };
})(Tool || (exports.Tool = Tool = {}));
const ToolFilterSensitiveLog = (obj) => {
    if (obj.toolSpecification !== undefined)
        return { toolSpecification: (0, exports.ToolSpecificationFilterSensitiveLog)(obj.toolSpecification)
        };
    if (obj.$unknown !== undefined)
        return { [obj.$unknown[0]]: 'UNKNOWN' };
};
exports.ToolFilterSensitiveLog = ToolFilterSensitiveLog;
const UserInputMessageContextFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.editorState && { editorState: (0, exports.EditorStateFilterSensitiveLog)(obj.editorState)
    }),
    ...(obj.shellState && { shellState: (0, exports.ShellStateFilterSensitiveLog)(obj.shellState)
    }),
    ...(obj.gitState && { gitState: (0, exports.GitStateFilterSensitiveLog)(obj.gitState)
    }),
    ...(obj.envState && { envState: (0, exports.EnvStateFilterSensitiveLog)(obj.envState)
    }),
    ...(obj.appStudioContext && { appStudioContext: (0, exports.AppStudioStateFilterSensitiveLog)(obj.appStudioContext)
    }),
    ...(obj.diagnostic && { diagnostic: (0, exports.DiagnosticFilterSensitiveLog)(obj.diagnostic)
    }),
    ...(obj.consoleState && { consoleState: (0, exports.ConsoleStateFilterSensitiveLog)(obj.consoleState)
    }),
    ...(obj.additionalContext && { additionalContext: obj.additionalContext.map(item => (0, exports.AdditionalContentEntryFilterSensitiveLog)(item))
    }),
    ...(obj.toolResults && { toolResults: obj.toolResults.map(item => (0, exports.ToolResultFilterSensitiveLog)(item))
    }),
    ...(obj.tools && { tools: obj.tools.map(item => (0, exports.ToolFilterSensitiveLog)(item))
    }),
});
exports.UserInputMessageContextFilterSensitiveLog = UserInputMessageContextFilterSensitiveLog;
const UserInputMessageFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.content && { content: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.userInputMessageContext && { userInputMessageContext: (0, exports.UserInputMessageContextFilterSensitiveLog)(obj.userInputMessageContext)
    }),
    ...(obj.images && { images: obj.images.map(item => (0, exports.ImageBlockFilterSensitiveLog)(item))
    }),
});
exports.UserInputMessageFilterSensitiveLog = UserInputMessageFilterSensitiveLog;
var ChatMessage;
(function (ChatMessage) {
    ChatMessage.visit = (value, visitor) => {
        if (value.userInputMessage !== undefined)
            return visitor.userInputMessage(value.userInputMessage);
        if (value.assistantResponseMessage !== undefined)
            return visitor.assistantResponseMessage(value.assistantResponseMessage);
        return visitor._(value.$unknown[0], value.$unknown[1]);
    };
})(ChatMessage || (exports.ChatMessage = ChatMessage = {}));
const ChatMessageFilterSensitiveLog = (obj) => {
    if (obj.userInputMessage !== undefined)
        return { userInputMessage: (0, exports.UserInputMessageFilterSensitiveLog)(obj.userInputMessage)
        };
    if (obj.assistantResponseMessage !== undefined)
        return { assistantResponseMessage: (0, exports.AssistantResponseMessageFilterSensitiveLog)(obj.assistantResponseMessage)
        };
    if (obj.$unknown !== undefined)
        return { [obj.$unknown[0]]: 'UNKNOWN' };
};
exports.ChatMessageFilterSensitiveLog = ChatMessageFilterSensitiveLog;
var CitationTarget;
(function (CitationTarget) {
    CitationTarget.visit = (value, visitor) => {
        if (value.location !== undefined)
            return visitor.location(value.location);
        if (value.range !== undefined)
            return visitor.range(value.range);
        return visitor._(value.$unknown[0], value.$unknown[1]);
    };
})(CitationTarget || (exports.CitationTarget = CitationTarget = {}));
const CitationEventFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.target && { target: obj.target
    }),
    ...(obj.citationText && { citationText: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.citationLink && { citationLink: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.CitationEventFilterSensitiveLog = CitationEventFilterSensitiveLog;
const CodeEventFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.content && { content: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.CodeEventFilterSensitiveLog = CodeEventFilterSensitiveLog;
const FollowupPromptEventFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.followupPrompt && { followupPrompt: (0, exports.FollowupPromptFilterSensitiveLog)(obj.followupPrompt)
    }),
});
exports.FollowupPromptEventFilterSensitiveLog = FollowupPromptEventFilterSensitiveLog;
exports.IntentType = {
    GLUE_SENSEI: "GLUE_SENSEI",
    RESOURCE_DATA: "RESOURCE_DATA",
    SUPPORT: "SUPPORT",
};
var IntentDataType;
(function (IntentDataType) {
    IntentDataType.visit = (value, visitor) => {
        if (value.string !== undefined)
            return visitor.string(value.string);
        return visitor._(value.$unknown[0], value.$unknown[1]);
    };
})(IntentDataType || (exports.IntentDataType = IntentDataType = {}));
const IntentsEventFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.intents && { intents: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.IntentsEventFilterSensitiveLog = IntentsEventFilterSensitiveLog;
const CloudWatchTroubleshootingLinkFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.label && { label: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.investigationPayload && { investigationPayload: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.defaultText && { defaultText: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.CloudWatchTroubleshootingLinkFilterSensitiveLog = CloudWatchTroubleshootingLinkFilterSensitiveLog;
const ModuleLinkFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.cloudWatchTroubleshootingLink && { cloudWatchTroubleshootingLink: (0, exports.CloudWatchTroubleshootingLinkFilterSensitiveLog)(obj.cloudWatchTroubleshootingLink)
    }),
});
exports.ModuleLinkFilterSensitiveLog = ModuleLinkFilterSensitiveLog;
const WebLinkFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.label && { label: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.url && { url: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.WebLinkFilterSensitiveLog = WebLinkFilterSensitiveLog;
const ActionFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.webLink && { webLink: (0, exports.WebLinkFilterSensitiveLog)(obj.webLink)
    }),
    ...(obj.moduleLink && { moduleLink: (0, exports.ModuleLinkFilterSensitiveLog)(obj.moduleLink)
    }),
});
exports.ActionFilterSensitiveLog = ActionFilterSensitiveLog;
const TextFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.content && { content: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.TextFilterSensitiveLog = TextFilterSensitiveLog;
const AlertComponentFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.text && { text: (0, exports.TextFilterSensitiveLog)(obj.text)
    }),
});
exports.AlertComponentFilterSensitiveLog = AlertComponentFilterSensitiveLog;
exports.AlertType = {
    ERROR: "ERROR",
    INFO: "INFO",
    WARNING: "WARNING",
};
const AlertFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.content && { content: obj.content.map(item => (0, exports.AlertComponentFilterSensitiveLog)(item))
    }),
});
exports.AlertFilterSensitiveLog = AlertFilterSensitiveLog;
const InfrastructureUpdateTransitionFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.currentState && { currentState: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.nextState && { nextState: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.InfrastructureUpdateTransitionFilterSensitiveLog = InfrastructureUpdateTransitionFilterSensitiveLog;
const InfrastructureUpdateFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.transition && { transition: (0, exports.InfrastructureUpdateTransitionFilterSensitiveLog)(obj.transition)
    }),
});
exports.InfrastructureUpdateFilterSensitiveLog = InfrastructureUpdateFilterSensitiveLog;
const StepComponentFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.text && { text: (0, exports.TextFilterSensitiveLog)(obj.text)
    }),
});
exports.StepComponentFilterSensitiveLog = StepComponentFilterSensitiveLog;
exports.StepState = {
    FAILED: "FAILED",
    IN_PROGRESS: "IN_PROGRESS",
    LOADING: "LOADING",
    PAUSED: "PAUSED",
    PENDING: "PENDING",
    STOPPED: "STOPPED",
    SUCCEEDED: "SUCCEEDED",
};
const StepFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.label && { label: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.content && { content: obj.content.map(item => (0, exports.StepComponentFilterSensitiveLog)(item))
    }),
});
exports.StepFilterSensitiveLog = StepFilterSensitiveLog;
const ProgressComponentFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.step && { step: (0, exports.StepFilterSensitiveLog)(obj.step)
    }),
});
exports.ProgressComponentFilterSensitiveLog = ProgressComponentFilterSensitiveLog;
const ProgressFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.content && { content: obj.content.map(item => (0, exports.ProgressComponentFilterSensitiveLog)(item))
    }),
});
exports.ProgressFilterSensitiveLog = ProgressFilterSensitiveLog;
const ResourceFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.title && { title: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.link && { link: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.description && { description: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.type && { type: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.ARN && { ARN: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.resourceJsonString && { resourceJsonString: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.ResourceFilterSensitiveLog = ResourceFilterSensitiveLog;
const ResourceListFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.action && { action: (0, exports.ActionFilterSensitiveLog)(obj.action)
    }),
    ...(obj.items && { items: obj.items.map(item => (0, exports.ResourceFilterSensitiveLog)(item))
    }),
});
exports.ResourceListFilterSensitiveLog = ResourceListFilterSensitiveLog;
const SectionComponentFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.text && { text: (0, exports.TextFilterSensitiveLog)(obj.text)
    }),
    ...(obj.alert && { alert: (0, exports.AlertFilterSensitiveLog)(obj.alert)
    }),
    ...(obj.resource && { resource: (0, exports.ResourceFilterSensitiveLog)(obj.resource)
    }),
    ...(obj.resourceList && { resourceList: (0, exports.ResourceListFilterSensitiveLog)(obj.resourceList)
    }),
});
exports.SectionComponentFilterSensitiveLog = SectionComponentFilterSensitiveLog;
const SectionFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.title && { title: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.content && { content: obj.content.map(item => (0, exports.SectionComponentFilterSensitiveLog)(item))
    }),
    ...(obj.action && { action: (0, exports.ActionFilterSensitiveLog)(obj.action)
    }),
});
exports.SectionFilterSensitiveLog = SectionFilterSensitiveLog;
const SuggestionFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.value && { value: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.SuggestionFilterSensitiveLog = SuggestionFilterSensitiveLog;
const SuggestionsFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.items && { items: obj.items.map(item => (0, exports.SuggestionFilterSensitiveLog)(item))
    }),
});
exports.SuggestionsFilterSensitiveLog = SuggestionsFilterSensitiveLog;
const TaskActionConfirmationFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.content && { content: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.TaskActionConfirmationFilterSensitiveLog = TaskActionConfirmationFilterSensitiveLog;
exports.TaskActionNoteType = {
    INFO: "INFO",
    WARNING: "WARNING",
};
const TaskActionNoteFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.content && { content: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.TaskActionNoteFilterSensitiveLog = TaskActionNoteFilterSensitiveLog;
const TaskActionFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.label && { label: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.note && { note: (0, exports.TaskActionNoteFilterSensitiveLog)(obj.note)
    }),
    ...(obj.payload && { payload: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.confirmation && { confirmation: (0, exports.TaskActionConfirmationFilterSensitiveLog)(obj.confirmation)
    }),
});
exports.TaskActionFilterSensitiveLog = TaskActionFilterSensitiveLog;
const TaskComponentFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.text && { text: (0, exports.TextFilterSensitiveLog)(obj.text)
    }),
    ...(obj.infrastructureUpdate && { infrastructureUpdate: (0, exports.InfrastructureUpdateFilterSensitiveLog)(obj.infrastructureUpdate)
    }),
    ...(obj.alert && { alert: (0, exports.AlertFilterSensitiveLog)(obj.alert)
    }),
    ...(obj.progress && { progress: (0, exports.ProgressFilterSensitiveLog)(obj.progress)
    }),
});
exports.TaskComponentFilterSensitiveLog = TaskComponentFilterSensitiveLog;
const TaskOverviewFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.label && { label: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.description && { description: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.TaskOverviewFilterSensitiveLog = TaskOverviewFilterSensitiveLog;
const TaskDetailsFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.overview && { overview: (0, exports.TaskOverviewFilterSensitiveLog)(obj.overview)
    }),
    ...(obj.content && { content: obj.content.map(item => (0, exports.TaskComponentFilterSensitiveLog)(item))
    }),
    ...(obj.actions && { actions: obj.actions.map(item => (0, exports.TaskActionFilterSensitiveLog)(item))
    }),
});
exports.TaskDetailsFilterSensitiveLog = TaskDetailsFilterSensitiveLog;
const InteractionComponentFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.text && { text: (0, exports.TextFilterSensitiveLog)(obj.text)
    }),
    ...(obj.alert && { alert: (0, exports.AlertFilterSensitiveLog)(obj.alert)
    }),
    ...(obj.infrastructureUpdate && { infrastructureUpdate: (0, exports.InfrastructureUpdateFilterSensitiveLog)(obj.infrastructureUpdate)
    }),
    ...(obj.progress && { progress: (0, exports.ProgressFilterSensitiveLog)(obj.progress)
    }),
    ...(obj.step && { step: (0, exports.StepFilterSensitiveLog)(obj.step)
    }),
    ...(obj.taskDetails && { taskDetails: (0, exports.TaskDetailsFilterSensitiveLog)(obj.taskDetails)
    }),
    ...(obj.suggestions && { suggestions: (0, exports.SuggestionsFilterSensitiveLog)(obj.suggestions)
    }),
    ...(obj.section && { section: (0, exports.SectionFilterSensitiveLog)(obj.section)
    }),
    ...(obj.resource && { resource: (0, exports.ResourceFilterSensitiveLog)(obj.resource)
    }),
    ...(obj.resourceList && { resourceList: (0, exports.ResourceListFilterSensitiveLog)(obj.resourceList)
    }),
    ...(obj.action && { action: (0, exports.ActionFilterSensitiveLog)(obj.action)
    }),
});
exports.InteractionComponentFilterSensitiveLog = InteractionComponentFilterSensitiveLog;
const InteractionComponentEntryFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.interactionComponent && { interactionComponent: (0, exports.InteractionComponentFilterSensitiveLog)(obj.interactionComponent)
    }),
});
exports.InteractionComponentEntryFilterSensitiveLog = InteractionComponentEntryFilterSensitiveLog;
const InteractionComponentsEventFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.interactionComponentEntries && { interactionComponentEntries: obj.interactionComponentEntries.map(item => (0, exports.InteractionComponentEntryFilterSensitiveLog)(item))
    }),
});
exports.InteractionComponentsEventFilterSensitiveLog = InteractionComponentsEventFilterSensitiveLog;
exports.InvalidStateReason = {
    INVALID_TASK_ASSIST_PLAN: "INVALID_TASK_ASSIST_PLAN",
};
const SupplementaryWebLinksEventFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.supplementaryWebLinks && { supplementaryWebLinks: obj.supplementaryWebLinks.map(item => (0, exports.SupplementaryWebLinkFilterSensitiveLog)(item))
    }),
});
exports.SupplementaryWebLinksEventFilterSensitiveLog = SupplementaryWebLinksEventFilterSensitiveLog;
const ToolResultEventFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.toolResult && { toolResult: (0, exports.ToolResultFilterSensitiveLog)(obj.toolResult)
    }),
});
exports.ToolResultEventFilterSensitiveLog = ToolResultEventFilterSensitiveLog;
const ToolUseEventFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.name && { name: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.input && { input: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.ToolUseEventFilterSensitiveLog = ToolUseEventFilterSensitiveLog;
var ChatResponseStream;
(function (ChatResponseStream) {
    ChatResponseStream.visit = (value, visitor) => {
        if (value.messageMetadataEvent !== undefined)
            return visitor.messageMetadataEvent(value.messageMetadataEvent);
        if (value.assistantResponseEvent !== undefined)
            return visitor.assistantResponseEvent(value.assistantResponseEvent);
        if (value.dryRunSucceedEvent !== undefined)
            return visitor.dryRunSucceedEvent(value.dryRunSucceedEvent);
        if (value.codeReferenceEvent !== undefined)
            return visitor.codeReferenceEvent(value.codeReferenceEvent);
        if (value.supplementaryWebLinksEvent !== undefined)
            return visitor.supplementaryWebLinksEvent(value.supplementaryWebLinksEvent);
        if (value.followupPromptEvent !== undefined)
            return visitor.followupPromptEvent(value.followupPromptEvent);
        if (value.codeEvent !== undefined)
            return visitor.codeEvent(value.codeEvent);
        if (value.intentsEvent !== undefined)
            return visitor.intentsEvent(value.intentsEvent);
        if (value.interactionComponentsEvent !== undefined)
            return visitor.interactionComponentsEvent(value.interactionComponentsEvent);
        if (value.toolUseEvent !== undefined)
            return visitor.toolUseEvent(value.toolUseEvent);
        if (value.toolResultEvent !== undefined)
            return visitor.toolResultEvent(value.toolResultEvent);
        if (value.citationEvent !== undefined)
            return visitor.citationEvent(value.citationEvent);
        if (value.invalidStateEvent !== undefined)
            return visitor.invalidStateEvent(value.invalidStateEvent);
        if (value.error !== undefined)
            return visitor.error(value.error);
        return visitor._(value.$unknown[0], value.$unknown[1]);
    };
})(ChatResponseStream || (exports.ChatResponseStream = ChatResponseStream = {}));
const ChatResponseStreamFilterSensitiveLog = (obj) => {
    if (obj.messageMetadataEvent !== undefined)
        return { messageMetadataEvent: obj.messageMetadataEvent
        };
    if (obj.assistantResponseEvent !== undefined)
        return { assistantResponseEvent: (0, exports.AssistantResponseEventFilterSensitiveLog)(obj.assistantResponseEvent)
        };
    if (obj.dryRunSucceedEvent !== undefined)
        return { dryRunSucceedEvent: obj.dryRunSucceedEvent
        };
    if (obj.codeReferenceEvent !== undefined)
        return { codeReferenceEvent: obj.codeReferenceEvent
        };
    if (obj.supplementaryWebLinksEvent !== undefined)
        return { supplementaryWebLinksEvent: (0, exports.SupplementaryWebLinksEventFilterSensitiveLog)(obj.supplementaryWebLinksEvent)
        };
    if (obj.followupPromptEvent !== undefined)
        return { followupPromptEvent: (0, exports.FollowupPromptEventFilterSensitiveLog)(obj.followupPromptEvent)
        };
    if (obj.codeEvent !== undefined)
        return { codeEvent: (0, exports.CodeEventFilterSensitiveLog)(obj.codeEvent)
        };
    if (obj.intentsEvent !== undefined)
        return { intentsEvent: (0, exports.IntentsEventFilterSensitiveLog)(obj.intentsEvent)
        };
    if (obj.interactionComponentsEvent !== undefined)
        return { interactionComponentsEvent: (0, exports.InteractionComponentsEventFilterSensitiveLog)(obj.interactionComponentsEvent)
        };
    if (obj.toolUseEvent !== undefined)
        return { toolUseEvent: (0, exports.ToolUseEventFilterSensitiveLog)(obj.toolUseEvent)
        };
    if (obj.toolResultEvent !== undefined)
        return { toolResultEvent: (0, exports.ToolResultEventFilterSensitiveLog)(obj.toolResultEvent)
        };
    if (obj.citationEvent !== undefined)
        return { citationEvent: (0, exports.CitationEventFilterSensitiveLog)(obj.citationEvent)
        };
    if (obj.invalidStateEvent !== undefined)
        return { invalidStateEvent: obj.invalidStateEvent
        };
    if (obj.error !== undefined)
        return { error: obj.error
        };
    if (obj.$unknown !== undefined)
        return { [obj.$unknown[0]]: 'UNKNOWN' };
};
exports.ChatResponseStreamFilterSensitiveLog = ChatResponseStreamFilterSensitiveLog;
exports.ChatTriggerType = {
    DIAGNOSTIC: "DIAGNOSTIC",
    INLINE_CHAT: "INLINE_CHAT",
    MANUAL: "MANUAL",
};
var CommandInput;
(function (CommandInput) {
    CommandInput.visit = (value, visitor) => {
        if (value.commandsList !== undefined)
            return visitor.commandsList(value.commandsList);
        return visitor._(value.$unknown[0], value.$unknown[1]);
    };
})(CommandInput || (exports.CommandInput = CommandInput = {}));
const CommandInputFilterSensitiveLog = (obj) => {
    if (obj.commandsList !== undefined)
        return { commandsList: smithy_client_1.SENSITIVE_STRING
        };
    if (obj.$unknown !== undefined)
        return { [obj.$unknown[0]]: 'UNKNOWN' };
};
exports.CommandInputFilterSensitiveLog = CommandInputFilterSensitiveLog;
const ConversationStateFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.history && { history: obj.history.map(item => (0, exports.ChatMessageFilterSensitiveLog)(item))
    }),
    ...(obj.currentMessage && { currentMessage: (0, exports.ChatMessageFilterSensitiveLog)(obj.currentMessage)
    }),
});
exports.ConversationStateFilterSensitiveLog = ConversationStateFilterSensitiveLog;
class DryRunOperationException extends QDeveloperStreamingServiceException_1.QDeveloperStreamingServiceException {
    name = "DryRunOperationException";
    $fault = "client";
    responseCode;
    constructor(opts) {
        super({
            name: "DryRunOperationException",
            $fault: "client",
            ...opts
        });
        Object.setPrototypeOf(this, DryRunOperationException.prototype);
        this.responseCode = opts.responseCode;
    }
}
exports.DryRunOperationException = DryRunOperationException;
exports.OutputFormat = {
    JAVA_CDK: "java/cdk",
    JSON_CFN: "json/cfn",
    PYTHON_CDK: "python/cdk",
    TYPESCRIPT_CDK: "typescript/cdk",
    YAML_CFN: "yaml/cfn",
};
exports.ServiceQuotaExceededExceptionReason = {
    CONVERSATION_LIMIT_EXCEEDED: "CONVERSATION_LIMIT_EXCEEDED",
};
class ServiceQuotaExceededException extends QDeveloperStreamingServiceException_1.QDeveloperStreamingServiceException {
    name = "ServiceQuotaExceededException";
    $fault = "client";
    reason;
    constructor(opts) {
        super({
            name: "ServiceQuotaExceededException",
            $fault: "client",
            ...opts
        });
        Object.setPrototypeOf(this, ServiceQuotaExceededException.prototype);
        this.reason = opts.reason;
    }
}
exports.ServiceQuotaExceededException = ServiceQuotaExceededException;
const SendMessageRequestFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.conversationState && { conversationState: (0, exports.ConversationStateFilterSensitiveLog)(obj.conversationState)
    }),
});
exports.SendMessageRequestFilterSensitiveLog = SendMessageRequestFilterSensitiveLog;
const SendMessageResponseFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.sendMessageResponse && { sendMessageResponse: 'STREAMING_CONTENT'
    }),
});
exports.SendMessageResponseFilterSensitiveLog = SendMessageResponseFilterSensitiveLog;
const GenerateCodeFromCommandsRequestFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.commands && { commands: (0, exports.CommandInputFilterSensitiveLog)(obj.commands)
    }),
});
exports.GenerateCodeFromCommandsRequestFilterSensitiveLog = GenerateCodeFromCommandsRequestFilterSensitiveLog;
var GenerateCodeFromCommandsResponseStream;
(function (GenerateCodeFromCommandsResponseStream) {
    GenerateCodeFromCommandsResponseStream.visit = (value, visitor) => {
        if (value.codeEvent !== undefined)
            return visitor.codeEvent(value.codeEvent);
        if (value.Error !== undefined)
            return visitor.Error(value.Error);
        if (value.QuotaLevelExceededError !== undefined)
            return visitor.QuotaLevelExceededError(value.QuotaLevelExceededError);
        if (value.ValidationError !== undefined)
            return visitor.ValidationError(value.ValidationError);
        return visitor._(value.$unknown[0], value.$unknown[1]);
    };
})(GenerateCodeFromCommandsResponseStream || (exports.GenerateCodeFromCommandsResponseStream = GenerateCodeFromCommandsResponseStream = {}));
const GenerateCodeFromCommandsResponseStreamFilterSensitiveLog = (obj) => {
    if (obj.codeEvent !== undefined)
        return { codeEvent: (0, exports.CodeEventFilterSensitiveLog)(obj.codeEvent)
        };
    if (obj.Error !== undefined)
        return { Error: obj.Error
        };
    if (obj.QuotaLevelExceededError !== undefined)
        return { QuotaLevelExceededError: obj.QuotaLevelExceededError
        };
    if (obj.ValidationError !== undefined)
        return { ValidationError: obj.ValidationError
        };
    if (obj.$unknown !== undefined)
        return { [obj.$unknown[0]]: 'UNKNOWN' };
};
exports.GenerateCodeFromCommandsResponseStreamFilterSensitiveLog = GenerateCodeFromCommandsResponseStreamFilterSensitiveLog;
const GenerateCodeFromCommandsResponseFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.generatedCodeFromCommandsResponse && { generatedCodeFromCommandsResponse: 'STREAMING_CONTENT'
    }),
});
exports.GenerateCodeFromCommandsResponseFilterSensitiveLog = GenerateCodeFromCommandsResponseFilterSensitiveLog;
